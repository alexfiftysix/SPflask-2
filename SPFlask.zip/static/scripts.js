function begone(element){
    console.log("Begone!");
    element.style.display = 'none';
}
