config = {
    'db_username': 'root',  # streetpieces
    'db_password': 'password',  # DatabaseAccessPassword3
    'db_name': 'StreetPiecesClean',  # SP
    'db_host': 'localhost',  # streetpieces.mysql.pythonanywhere-services.com
    'secret': '\x146\xd6U\xf0\xcc\x8b_\xa0\x9d\x8f;\x95b\xb3r'
}

new_config = {
    'db_username': 'streetpieces',
    'db_password': 'PassPy33',
    'db_name': 'streetpieces$SP',
    'db_host': 'streetpieces.mysql.pythonanywhere-services.com'
}
