config = {
    'db_username': 'root',
    'db_password': 'password',
    'db_name': 'StreetPiecesClean',
    'db_host': 'localhost'
}
