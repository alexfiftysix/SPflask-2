def gigs_list():
    gigs_ret = [
        {
            'id': 1,
            'title': 'Rock out with your rock',
            'location': 'The Zoo',
            'date': '20-04-1992',
            'price': '$15',
            'link': 'https://www.oztix.com/1248afnw'
        },
        {
            'id': 2,
            'title': 'Bear Party',
            'location': 'Black Bear',
            'date': '21-04-1992',
            'price': '$25',
            'link': 'https://www.oztix.com/1248afnw4'
        }
    ]
    return gigs_ret


def contact_list():
    contacts_ret = [
        {
            'title': 'Instagram',
            'value': '@streetpieces'
        },
        {
            'title': 'email',
            'value': 'streetpieces@gmail.com'
        },
        {
            'title': 'Phone - Alex',
            'value': '0402 684 288'
        }
    ]
    return contacts_ret
