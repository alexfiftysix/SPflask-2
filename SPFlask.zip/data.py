def contact_list():
    contacts_ret = [
        {
            'title': 'Instagram',
            'value': '@streetpieces'
        },
        {
            'title': 'email',
            'value': 'streetpieces@gmail.com'
        },
        {
            'title': 'Phone - Alex',
            'value': '0402 684 288'
        }
    ]
    return contacts_ret
